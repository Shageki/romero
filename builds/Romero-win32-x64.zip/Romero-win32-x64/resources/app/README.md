# Romero
 A 7 Days to Die settings editor and manager.

## What is Romero?
Romero is mostly a personal experiment in writing a simple Electron app. It stands for **R**eal z**OM**bies hav**E** vulne**R**able heads. **O**.

## What does it do?
Romero will autodetect any local 7D2D install folders and allow you to make a series of tweaks to the config files contained therein.

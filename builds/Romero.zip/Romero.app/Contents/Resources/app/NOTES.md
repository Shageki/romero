Enabled mods are written as text in a comment block - parse the string to find the start of the block then read each key (like yaml?)

Mod scripts are each separately applicable in the scripts folder - each does a set of changes

System should detect a backup and create a new one as necessary - just copy the config file changed and allow an easy method to revert (maybe a versioning system?)
  ie vanilla, x mods enabled, etc etc


TODO
Change console emulator to append a new element to the body and load the console there
- there should be a button at the bottom with an icon in pure CSS for the console
- clicking it sliders up a pane that stays aligned to the bottom of the screen and attaches the console to that pane
- long term maybe it can open a separate window or something
- should be encapsulated this way in that it will allow you to simply include the module and call the init part (or automatically init if possible?) and it is there on whatever app.

Similar system info utility?
-

TODO
Set up menubar per https://electronjs.org/docs/api/menu


Log #65b0ed
Warn #e3be7e
Error #de6d77





# Design Notes
Feature roadmap and acceptance criteria.


## Key App Functionality
These are the core v1.0 features.

## Main controls the flow


### UI Update hooks
Functions:
* Game installs: @gameFoundEvent, directory => updates found installs UI element
    * `<tr data-directory="@directory"><td>Select</td><td>@directory</td></tr>`
* Game details: @gameDetailUpdateEvent => update functions
    * Files status: @fileStateObject => updates UI
    * Mods status: @fileStateObject => updates UI

### Find game installs
Functions:
* Detect OS:  none => object (os info)
* Search defaults: none => if valid => array (directories), eventTrigger
* Search config file locations: none => if valid => array (directories), eventTrigger
    * Read from config: none => array(search directories)
* Search manually: none => if valid =>   array (directories), eventTrigger(s)
* Valid Location: @directory => boolean, @returnDirectory(may be different)
    * Just looks at specific hierarchical levels (ie `if ../ == '7d2d'`)
    * If any return true, then get that full directory name and provide
        * This is smart - it can START without any up/down hierarchy logic, and just check the provided directory. Once we build in more robust searching, it won't affect other functions, since they are working off the returned directory from this function anyways.
     * SearchUp: @directory, @callCount, boolean => boolean, callCount *work in progress*
         * If boolean == true, return true and directory
         * If boolean == false && callCount < search threshold, call self w/ new directories
             * Recursive to a limit set in config
         * If boolean == false && callCount >= search threshold, return false
    * Add to config: @directory => updates config file

### File version management
Functions:
* Game File Status: @directory @filesArray(of game files we are concerned with) => object(gameFiles), @gameDetailUpdateEvent
```
var gameFiles = [
    {
        fileName: "items.xml",
        mods: [
            {
                modName: "Headshot Damage",
                applications: 3
            }
        ]
    }
]
```
*think about this data structure - it will be heavily referenced for UI and file operations*
*

Backup key files in data folder alongside source if they do not exist.
* format is `_romero_backup_filename_extension_timestamp_.extension`
    * ie `_romero_backup_items_xml_2018101214362803.xml`
    * Split w/ _ will allow us to easily parse the string
Restore to backup (drop down to select backup file w/ pretty date/time stamp).
Reset files (warning to validate files after)
Purge files (warning that this will delete backups and to validate files after)

### Mod management
Functions:
* Available mods: none =>
* Detect mod: @filename, @mod_name => boolean
* Read mod count: @filename, @mod_name => check if exists =>string (count)
* Write mod count: @filename, @mod_name, @count => check if exists => writes to file
    * Has to read first, if unable to find, writes new line, otherwise overwrites
* Apply mod: @directory, @mod_name, @direction(apply/remove) => writes to file, @gameDetailUpdateEvent

Write mod text block to file in comment block
``` html
<!-- Romero Mods
Headshot damage: 1
Bigger hordes: 1
Durable materials: 3
Stronger tools: 2
-->
```

Check for mod state by reading file for text block and show applications
* https://stackoverflow.com/questions/6156501/read-a-file-one-line-at-a-time-in-node-js
Apply mod (runs the apply script)
* Adds to application count
Remove mod (runs the undo script)
* Reduces application count
    * User cannot undo if 0 applications detected


## Future Updates
These are features that may be included in future releases.


### Manage server games
Swap server config file (similar to file version management functionality) but with unique UI

### Link to Night of the Living Dead
Play the original 1968 original from Archive.org (since it is public domain)
* https://archive.org/details/Night.Of.The.Living.Dead_1080p







# What I've learned...
Anything related to Electron / Node.js development.

## Visual Stuff
By default, borders and margins will cause hell with unexpected scrolls at 100%. Apply box sizing to all elements.
```css
* {
  box-sizing: border-box;
}
```

Similarly, cursor and click behavior will be like a website - apply global body styling and make interactive items explicitly touchable with classes.
```css
body {
  pointer-events: none;
  user-select: none;
}
input {
  pointer-events: auto;
  cursor: pointer;
}
.no_touching * {
  pointer-events: none !important;
  cursor: default !important;
}
.touching {
  pointer-events: auto;
  cursor: pointer;
}
```
